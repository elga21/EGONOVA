const BACKEND = "https://TU_BACKEND_RENDER_URL"; // reemplaza por tu URL
const sessionId = "sess_" + Math.random().toString(36).slice(2,9);

async function setMode(mode) {
  await fetch(BACKEND + "/set-mode", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ session_id: sessionId, mode })
  });
}

document.getElementById("modoSelect").addEventListener("change", (e) => {
  setMode(e.target.value);
});

document.getElementById("sendBtn").addEventListener("click", enviar);
document.getElementById("inputMsg").addEventListener("keydown", (e) => {
  if (e.key === "Enter") enviar();
});

async function enviar() {
  const input = document.getElementById("inputMsg");
  const chat = document.getElementById("chat");
  const nombre = document.getElementById("nombre").value;
  const email = document.getElementById("email").value;

  const texto = input.value;
  if (!texto) return;

  chat.innerHTML += `<p class='user'><b>Tú:</b> ${texto}</p>`;
  input.value = "";
  chat.scrollTop = chat.scrollHeight;

  try {
    const res = await fetch(BACKEND + "/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        session_id: sessionId,
        mensaje: texto,
        nombre,
        email
      })
    });

    const data = await res.json();

    chat.innerHTML += `<p class='ia'><b>IA [${data.modo}]:</b> ${data.respuesta}</p>`;
    chat.innerHTML += `<p class='ia'><b>Cotización estimada:</b> ${data.cotizacion}</p>`;
    chat.scrollTop = chat.scrollHeight;
  } catch (e) {
    chat.innerHTML += `<p class='ia'><b>IA:</b> Error conectando al backend.</p>`;
  }
}
