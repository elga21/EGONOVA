// backend/server.js
import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import fs from "fs";
import fetch from "node-fetch";
import { initDB } from "./db.js";
import { cotizar } from "./cotizador.js";
import nodemailer from "nodemailer";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

let db;
(async () => { db = await initDB(); })();

// Prompt base (tema de la tienda)
const sistema = {
  role: "system",
  content: `
Eres el asistente oficial de MiTiendaTech, especialista en servicios de desarrollo de software y electrónica.
Reglas:
- RESPONDER SOLO sobre los servicios de MiTiendaTech.
- Clasificar solicitudes y usar un formato claro.
- Si la consulta está fuera de tema, responder: "Solo puedo responder preguntas relacionadas con los servicios de MiTiendaTech."
- Siempre en español.
`
};

// Memoria corta
const MEMORY_LIMIT = 8;
const sessions = {};

// nodemailer
let transporter = null;
if (process.env.SMTP_HOST && process.env.SMTP_USER) {
  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: false,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  });
}

async function pushMessage(session_id, role, content) {
  if (!sessions[session_id]) sessions[session_id] = [];
  sessions[session_id].push({ role, content });
  if (sessions[session_id].length > MEMORY_LIMIT) sessions[session_id].shift();

  try {
    await db.run(
      `INSERT INTO conversaciones (session_id, role, content) VALUES (?, ?, ?)`,
      session_id, role, content
    );
  } catch (e) { console.error("DB error:", e); }
}

app.post("/set-mode", (req, res) => {
  const { session_id, mode } = req.body;
  if (!session_id) return res.status(400).json({ error: "session_id requerido" });
  sessions[session_id] = sessions[session_id] || [];
  sessions[session_id].mode = mode || "vendedor";
  res.json({ ok: true, mode: sessions[session_id].mode });
});

app.post("/chat", async (req, res) => {
  const { session_id = "anon", mensaje, nombre, email } = req.body;
  if (!mensaje) return res.status(400).json({ error: "mensaje requerido" });

  await pushMessage(session_id, "user", mensaje);

  const cotizacionTexto = cotizar(mensaje);

  let memoria = sessions[session_id] ? sessions[session_id].slice(-MEMORY_LIMIT) : [];
  let infoTienda = {};
  try {
    if (fs.existsSync("./data.json")) {
      infoTienda = JSON.parse(fs.readFileSync("./data.json","utf8"));
    }
  } catch(e){ console.error(e); }

  const modo = (sessions[session_id] && sessions[session_id].mode) || "vendedor";

  const promptMode = {
    role: "system",
    content: `Modo actual: ${modo}. Actúa según ese rol (vendedor/técnico/soporte/cotizador). Clasifica la solicitud y ofrece preguntas para clarificar si hace falta.`
  };

  const systemInfo = {
    role: "system",
    content: "Información interna: " + JSON.stringify(infoTienda)
  };

  const messagesToSend = [
    sistema,
    promptMode,
    systemInfo,
    ...memoria,
    { role: "user", content: mensaje }
  ];

  try {
    const respuesta = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENROUTER_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "meta-llama/llama-3.1-8b-instruct",
        messages: messagesToSend
      })
    });

    const data = await respuesta.json();
    const textoIA = data?.choices?.[0]?.message?.content || "No se obtuvo respuesta de la IA.";

    await pushMessage(session_id, "assistant", textoIA);

    await db.run(
      `INSERT INTO solicitudes (nombre, email, tipo, mensaje, cotizacion, respuesta_ia) VALUES (?, ?, ?, ?, ?, ?)`,
      nombre || null,
      email || null,
      modo,
      mensaje,
      cotizacionTexto,
      textoIA
    );

    if (transporter && process.env.EMAIL_TO) {
      try {
        await transporter.sendMail({
          from: process.env.EMAIL_FROM,
          to: process.env.EMAIL_TO,
          subject: `Nueva solicitud - ${modo}`,
          text: `Nombre: ${nombre || "N/A"}\nEmail: ${email || "N/A"}\nTipo: ${modo}\nMensaje: ${mensaje}\nCotización: ${cotizacionTexto}\n\nRespuesta IA:\n${textoIA}`
        });
      } catch (e) {
        console.error("Error enviando email:", e);
      }
    }

    res.json({
      respuesta: textoIA,
      cotizacion: cotizacionTexto,
      modo
    });

  } catch (error) {
    console.error("Error IA:", error);
    res.status(500).json({ respuesta: "Error conectando a la IA." });
  }
});

app.get("/solicitudes", async (req, res) => {
  try {
    const filas = await db.all(`SELECT * FROM solicitudes ORDER BY created_at DESC LIMIT 200`);
    res.json(filas);
  } catch (e) {
    res.status(500).json({ error: "Error DB" });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log("Servidor IA escuchando en puerto " + port));
